# UE BIMA (MU4II600) 
gives fundamental knowledge in image processing 
https://www-master.ufr-info-p6.jussieu.fr/parcours/ima.new/bima/ 
* Introduction
* Améliorations globales d'images
* Transformée de Fourier
* Numérisation des images - Fourier avancé
* Filtrage d'images - couleur
* Détection de contours
* Extraction de primitives
* Segmentation
* Descripteurs d'image - similarité
* ACP
* Eigenfaces

### Binome:
* Amine Djeghri
* Arthur Esquerre-Pourtère
